Welcome to the MDA Toolchain installer.

The MDA Toolchain is a suite of softwares for creating applications with Java, UML 
and MDA from the design to the deployment on J2EE servers.

It features the following open source softwares, all released under an open source 
license:
- ArgoUML 0.20alpha1, http://argouml.tigris.org (BSD)
- AndroMDA 3.1, http://www.andromda.org (BSD)
- Maven 1.0.2, http://maven.apache.org (ASL 2.0)
- Ant 1.6.5, http://ant.apache.org (ASL 2.0)

Additionally this suite features also this optionnal softwares:
- Tomcat 5.5.12, http://tomcat.apache.org (ASL 2.0)
- Geronimo 1.0-HEAD, http://geronimo.apache.org (ASL 2.0)
- OpenLaszlo, http://www.openlaszlo.org (CPL 1.0)

Also a lot of other open source frameworks and components are used in one application
but it's a too long list to write it here. But i would thanks the authors of Struts,
Apache Commons, Log4J, XDoclet... and all the authors of the numerous projects.
This installer is made with IzPack (http://www.izforge.com, ASL 2.0).

Feel free to report bugs to ludovic.maitre@free.fr and to visit my website :
http://www.ubik-products.com/

Best regards and have a good day,
Ludo
